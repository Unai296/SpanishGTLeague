import type React from "react"
import "@/app/globals.css"
import { Inter } from "next/font/google"
import { ThemeProvider } from "@/components/theme-provider"

const inter = Inter({ subsets: ["latin"] })

export const metadata = {
  title: "Spanish GT League - Liga de Gran Turismo 7",
  description:
    "Plataforma web oficial de nuestra liga de Gran Turismo 7, donde pilotos pueden seguir el calendario, resultados, clasificaciones y más. Simracing competitivo en español, todo en un solo lugar.",
  icons: {
    icon: [{ url: "/images/spanish-gt-league-logo.webp" }],
  },
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="es" suppressHydrationWarning className="dark">
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="dark" enableSystem={false} disableTransitionOnChange>
          {children}
        </ThemeProvider>
      </body>
    </html>
  )
}
