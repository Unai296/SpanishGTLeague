import Link from "next/link"
import { Trophy } from "lucide-react"

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"

export default function ClasificacionesPage() {
  // En una aplicación real, estos datos vendrían de una API o base de datos
  const driverStandings = [
    {
      position: 1,
      driver: "Carlos Martínez",
      team: "Racing Bulls",
      avatar: "/placeholder.svg?height=40&width=40",
      points: 210,
      wins: 4,
      podiums: 7,
      fastestLaps: 3,
    },
    {
      position: 2,
      driver: "Miguel Sánchez",
      team: "Speed Masters",
      avatar: "/placeholder.svg?height=40&width=40",
      points: 185,
      wins: 3,
      podiums: 6,
      fastestLaps: 2,
    },
    {
      position: 3,
      driver: "Javier López",
      team: "Velocity Racing",
      avatar: "/placeholder.svg?height=40&width=40",
      points: 170,
      wins: 2,
      podiums: 5,
      fastestLaps: 1,
    },
    {
      position: 4,
      driver: "Antonio García",
      team: "Apex Predators",
      avatar: "/placeholder.svg?height=40&width=40",
      points: 156,
      wins: 1,
      podiums: 4,
      fastestLaps: 2,
    },
    {
      position: 5,
      driver: "David Rodríguez",
      team: "Turbo Racers",
      avatar: "/placeholder.svg?height=40&width=40",
      points: 142,
      wins: 1,
      podiums: 3,
      fastestLaps: 1,
    },
    {
      position: 6,
      driver: "Alejandro Fernández",
      team: "Drift Kings",
      avatar: "/placeholder.svg?height=40&width=40",
      points: 128,
      wins: 0,
      podiums: 2,
      fastestLaps: 0,
    },
    {
      position: 7,
      driver: "Sergio Gómez",
      team: "Racing Bulls",
      avatar: "/placeholder.svg?height=40&width=40",
      points: 115,
      wins: 0,
      podiums: 1,
      fastestLaps: 1,
    },
    {
      position: 8,
      driver: "Pablo Martín",
      team: "Speed Masters",
      avatar: "/placeholder.svg?height=40&width=40",
      points: 98,
      wins: 0,
      podiums: 1,
      fastestLaps: 0,
    },
    {
      position: 9,
      driver: "Luis Torres",
      team: "Velocity Racing",
      avatar: "/placeholder.svg?height=40&width=40",
      points: 87,
      wins: 0,
      podiums: 0,
      fastestLaps: 1,
    },
    {
      position: 10,
      driver: "Raúl Jiménez",
      team: "Apex Predators",
      avatar: "/placeholder.svg?height=40&width=40",
      points: 76,
      wins: 0,
      podiums: 0,
      fastestLaps: 0,
    },
    {
      position: 11,
      driver: "Fernando Ruiz",
      team: "Turbo Racers",
      avatar: "/placeholder.svg?height=40&width=40",
      points: 65,
      wins: 0,
      podiums: 0,
      fastestLaps: 0,
    },
    {
      position: 12,
      driver: "Marcos Díaz",
      team: "Drift Kings",
      avatar: "/placeholder.svg?height=40&width=40",
      points: 54,
      wins: 0,
      podiums: 0,
      fastestLaps: 0,
    },
  ]

  const teamStandings = [
    { position: 1, team: "Racing Bulls", logo: "/placeholder.svg?height=40&width=40", points: 325, wins: 4 },
    { position: 2, team: "Speed Masters", logo: "/placeholder.svg?height=40&width=40", points: 283, wins: 3 },
    { position: 3, team: "Velocity Racing", logo: "/placeholder.svg?height=40&width=40", points: 257, wins: 2 },
    { position: 4, team: "Apex Predators", logo: "/placeholder.svg?height=40&width=40", points: 232, wins: 1 },
    { position: 5, team: "Turbo Racers", logo: "/placeholder.svg?height=40&width=40", points: 207, wins: 1 },
    { position: 6, team: "Drift Kings", logo: "/placeholder.svg?height=40&width=40", points: 182, wins: 0 },
  ]

  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="flex-1">
        <div className="container mx-auto px-4 py-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold">Clasificaciones</h1>
            <p className="mt-2 text-muted-foreground">
              Consulta las clasificaciones actualizadas de pilotos y equipos de la temporada
            </p>
          </div>

          <Tabs defaultValue="pilotos" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="pilotos">Clasificación de Pilotos</TabsTrigger>
              <TabsTrigger value="equipos">Clasificación de Equipos</TabsTrigger>
            </TabsList>
            <TabsContent value="pilotos" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>Campeonato de Pilotos</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="rounded-lg border">
                    <div className="hidden grid-cols-12 gap-2 border-b bg-muted p-3 text-sm font-medium sm:grid">
                      <div className="col-span-1 text-center">#</div>
                      <div className="col-span-3">Piloto</div>
                      <div className="col-span-3">Equipo</div>
                      <div className="col-span-1 text-center">
                        <Trophy className="mx-auto h-4 w-4" />
                        <span className="sr-only">Victorias</span>
                      </div>
                      <div className="col-span-1 text-center">Podios</div>
                      <div className="col-span-1 text-center">VR</div>
                      <div className="col-span-2 text-right">Puntos</div>
                    </div>
                    {driverStandings.map((driver) => (
                      <div
                        key={driver.position}
                        className={`grid grid-cols-6 gap-2 border-b p-3 text-sm last:border-0 sm:grid-cols-12 ${
                          driver.position <= 3 ? "bg-muted/30" : ""
                        }`}
                      >
                        <div className="col-span-1 text-center font-medium">{driver.position}</div>
                        <div className="col-span-3 flex items-center gap-2">
                          <Avatar className="h-6 w-6">
                            <AvatarImage src={driver.avatar || "/placeholder.svg"} alt={driver.driver} />
                            <AvatarFallback>{driver.driver.charAt(0)}</AvatarFallback>
                          </Avatar>
                          <Link
                            href={`/pilotos/${driver.driver.toLowerCase().replace(/\s+/g, "-")}`}
                            className="truncate hover:underline"
                          >
                            {driver.driver}
                          </Link>
                        </div>
                        <div className="col-span-3 hidden items-center sm:flex">
                          <Link
                            href={`/equipos/${driver.team.toLowerCase().replace(/\s+/g, "-")}`}
                            className="truncate text-muted-foreground hover:underline"
                          >
                            {driver.team}
                          </Link>
                        </div>
                        <div className="col-span-1 hidden text-center sm:block">{driver.wins}</div>
                        <div className="col-span-1 hidden text-center sm:block">{driver.podiums}</div>
                        <div className="col-span-1 hidden text-center sm:block">{driver.fastestLaps}</div>
                        <div className="col-span-2 text-right font-medium">{driver.points}</div>
                      </div>
                    ))}
                  </div>
                  <div className="mt-4 text-sm text-muted-foreground">
                    <p>VR = Vueltas Rápidas</p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="equipos" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>Campeonato de Equipos</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="rounded-lg border">
                    <div className="grid grid-cols-8 gap-2 border-b bg-muted p-3 text-sm font-medium">
                      <div className="col-span-1 text-center">#</div>
                      <div className="col-span-4">Equipo</div>
                      <div className="col-span-1 text-center">
                        <Trophy className="mx-auto h-4 w-4" />
                        <span className="sr-only">Victorias</span>
                      </div>
                      <div className="col-span-2 text-right">Puntos</div>
                    </div>
                    {teamStandings.map((team) => (
                      <div
                        key={team.position}
                        className={`grid grid-cols-8 gap-2 border-b p-3 text-sm last:border-0 ${
                          team.position <= 3 ? "bg-muted/30" : ""
                        }`}
                      >
                        <div className="col-span-1 text-center font-medium">{team.position}</div>
                        <div className="col-span-4 flex items-center gap-2">
                          <Avatar className="h-6 w-6">
                            <AvatarImage src={team.logo || "/placeholder.svg"} alt={team.team} />
                            <AvatarFallback>{team.team.charAt(0)}</AvatarFallback>
                          </Avatar>
                          <Link
                            href={`/equipos/${team.team.toLowerCase().replace(/\s+/g, "-")}`}
                            className="truncate hover:underline"
                          >
                            {team.team}
                          </Link>
                        </div>
                        <div className="col-span-1 text-center">{team.wins}</div>
                        <div className="col-span-2 text-right font-medium">{team.points}</div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          <div className="mt-12 rounded-lg bg-muted p-6">
            <h2 className="mb-4 text-2xl font-bold">Sistema de Puntuación</h2>
            <div className="grid gap-6 md:grid-cols-2">
              <div>
                <h3 className="mb-2 text-lg font-medium">Puntos por Posición</h3>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>1° lugar: 25 puntos</div>
                  <div>6° lugar: 8 puntos</div>
                  <div>2° lugar: 18 puntos</div>
                  <div>7° lugar: 6 puntos</div>
                  <div>3° lugar: 15 puntos</div>
                  <div>8° lugar: 4 puntos</div>
                  <div>4° lugar: 12 puntos</div>
                  <div>9° lugar: 2 puntos</div>
                  <div>5° lugar: 10 puntos</div>
                  <div>10° lugar: 1 punto</div>
                </div>
                <p className="mt-2 text-sm text-muted-foreground">Punto adicional por vuelta rápida en carrera</p>
              </div>
              <div>
                <h3 className="mb-2 text-lg font-medium">Reglas Adicionales</h3>
                <ul className="list-inside list-disc space-y-1 text-muted-foreground">
                  <li>Se deben completar al menos el 75% de las vueltas para puntuar</li>
                  <li>En caso de empate, se decide por mayor número de victorias</li>
                  <li>Los puntos de equipo son la suma de los puntos de sus pilotos</li>
                  <li>Las penalizaciones pueden resultar en pérdida de puntos</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
