import Image from "next/image"
import Link from "next/link"
import { CalendarIcon, MapPinIcon } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

export function LatestResults() {
  // En una aplicación real, estos datos vendrían de una API o base de datos
  const latestRace = {
    id: "race-6",
    name: "Gran Premio de Spa",
    circuit: "Spa Francorchamps",
    country: "Bélgica",
    flag: "🇧🇪",
    date: "Completada",
    image: "/placeholder.svg?height=300&width=600",
    results: [
      {
        position: 1,
        driver: "Carlos Martínez",
        team: "Racing Bulls",
        avatar: "/placeholder.svg?height=40&width=40",
        time: "32:45.123",
        points: 25,
      },
      {
        position: 2,
        driver: "Miguel Sánchez",
        team: "Speed Masters",
        avatar: "/placeholder.svg?height=40&width=40",
        time: "32:47.456",
        points: 18,
      },
      {
        position: 3,
        driver: "Javier López",
        team: "Velocity Racing",
        avatar: "/placeholder.svg?height=40&width=40",
        time: "32:48.789",
        points: 15,
      },
      {
        position: 4,
        driver: "Antonio García",
        team: "Apex Predators",
        avatar: "/placeholder.svg?height=40&width=40",
        time: "32:50.012",
        points: 12,
      },
      {
        position: 5,
        driver: "David Rodríguez",
        team: "Turbo Racers",
        avatar: "/placeholder.svg?height=40&width=40",
        time: "32:52.345",
        points: 10,
      },
    ],
  }

  return (
    <Card className="overflow-hidden bg-black border-yellow-500 text-white">
      <div className="relative h-[120px] w-full">
        <Image src={latestRace.image || "/placeholder.svg"} alt={latestRace.circuit} fill className="object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent"></div>
      </div>
      <CardHeader>
        <CardTitle className="text-2xl flex items-center gap-2">
          <span className="text-xl">{latestRace.flag}</span> {latestRace.name}
        </CardTitle>
        <div className="flex flex-wrap items-center gap-4 text-sm text-gray-400">
          <div className="flex items-center gap-1">
            <MapPinIcon className="h-4 w-4 text-yellow-500" />
            <span>{latestRace.circuit}</span>
          </div>
          <div className="flex items-center gap-1">
            <CalendarIcon className="h-4 w-4 text-yellow-500" />
            <span>{latestRace.date}</span>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="rounded-lg border border-gray-800">
          <div className="grid grid-cols-12 gap-2 border-b border-gray-800 bg-gray-900 p-3 text-sm font-medium">
            <div className="col-span-1 text-center">#</div>
            <div className="col-span-5">Piloto</div>
            <div className="col-span-3 hidden sm:block">Equipo</div>
            <div className="col-span-2 text-right">Tiempo</div>
            <div className="col-span-1 text-right">Pts</div>
          </div>
          {latestRace.results.map((result) => (
            <div
              key={result.position}
              className="grid grid-cols-12 gap-2 border-b border-gray-800 p-3 text-sm last:border-0"
            >
              <div className="col-span-1 text-center font-medium">
                {result.position === 1 && <span className="text-yellow-500">{result.position}</span>}
                {result.position === 2 && <span className="text-gray-400">{result.position}</span>}
                {result.position === 3 && <span className="text-amber-700">{result.position}</span>}
                {result.position > 3 && <span>{result.position}</span>}
              </div>
              <div className="col-span-5 flex items-center gap-2">
                <Avatar className="h-6 w-6">
                  <AvatarImage src={result.avatar || "/placeholder.svg"} alt={result.driver} />
                  <AvatarFallback>{result.driver.charAt(0)}</AvatarFallback>
                </Avatar>
                <span className="truncate">{result.driver}</span>
              </div>
              <div className="col-span-3 hidden items-center sm:flex">
                <span className="truncate text-gray-400">{result.team}</span>
              </div>
              <div className="col-span-2 text-right font-mono">{result.time}</div>
              <div className="col-span-1 text-right font-medium text-red-500">{result.points}</div>
            </div>
          ))}
        </div>
      </CardContent>
      <CardFooter>
        <Button className="w-full bg-yellow-500 hover:bg-yellow-600 text-black" asChild>
          <Link href={`/resultados/${latestRace.id}`}>Ver Resultados Completos</Link>
        </Button>
      </CardFooter>
    </Card>
  )
}
