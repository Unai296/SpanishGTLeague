import Link from "next/link"
import Image from "next/image"

export function Footer() {
  return (
    <footer className="border-t bg-black text-white">
      <div className="container px-4 py-8 md:py-12">
        <div className="grid gap-8 md:grid-cols-2">
          <div>
            <Link href="/" className="flex items-center gap-2">
              <Image
                src="/images/spanish-gt-league-logo.webp"
                alt="Spanish GT League Logo"
                width={60}
                height={60}
                className="rounded-md"
              />
              <span className="text-xl font-bold">Spanish GT League</span>
            </Link>
            <p className="mt-4 text-sm text-gray-400">
              La plataforma oficial de nuestra liga de Gran Turismo 7. Simracing competitivo en español, todo en un solo
              lugar.
            </p>
          </div>

          <div>
            <h3 className="mb-4 text-lg font-semibold">Enlaces Rápidos</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/calendario" className="text-gray-400 transition-colors hover:text-white">
                  Calendario
                </Link>
              </li>
              <li>
                <Link href="/equipos" className="text-gray-400 transition-colors hover:text-white">
                  Equipos
                </Link>
              </li>
              <li>
                <Link href="/reglamento" className="text-gray-400 transition-colors hover:text-white">
                  Reglamento
                </Link>
              </li>
            </ul>
          </div>
        </div>
        <div className="mt-8 border-t border-gray-800 pt-8 text-center text-sm text-gray-400">
          <p>&copy; {new Date().getFullYear()} Spanish GT League. Todos los derechos reservados.</p>
          <p className="mt-1">
            Gran Turismo es una marca registrada de Sony Interactive Entertainment Inc. Esta web no está afiliada con
            Sony.
          </p>
        </div>
      </div>
    </footer>
  )
}
