import Image from "next/image"
import Link from "next/link"
import { CalendarIcon, ClockIcon, MapPinIcon, CarIcon } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export function NextRace() {
  // Actualizar los datos de la próxima carrera
  const nextRace = {
    id: "race-7",
    name: "Gran Premio de Monza",
    circuit: "Monza",
    country: "Italia",
    flag: "🇮🇹",
    date: "Próximamente",
    time: "21:00 CEST",
    category: "GT3",
    image: "/placeholder.svg?height=300&width=600",
    description:
      "Séptima carrera de la temporada en el legendario circuito de Monza, conocido como el 'Templo de la Velocidad', con largas rectas y curvas de alta velocidad.",
    weatherForecast: "Soleado, 24°C",
    laps: 18,
    distance: "104.2 km",
  }

  return (
    <Card className="overflow-hidden bg-black border-red-600 text-white">
      <div className="relative h-[200px] w-full sm:h-[300px]">
        <Image src={nextRace.image || "/placeholder.svg"} alt={nextRace.circuit} fill className="object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent"></div>
      </div>
      <CardHeader>
        <CardTitle className="text-2xl flex items-center gap-2">
          <span className="text-xl">{nextRace.flag}</span> {nextRace.name}
        </CardTitle>
      </CardHeader>
      <CardContent className="grid gap-6">
        <div className="grid gap-3">
          <div className="flex items-center gap-2">
            <MapPinIcon className="h-4 w-4 text-red-500" />
            <span>{nextRace.circuit}</span>
          </div>
          <div className="flex items-center gap-2">
            <CalendarIcon className="h-4 w-4 text-red-500" />
            <span>{nextRace.date}</span>
          </div>
          <div className="flex items-center gap-2">
            <ClockIcon className="h-4 w-4 text-red-500" />
            <span>{nextRace.time}</span>
          </div>
          <div className="flex items-center gap-2">
            <CarIcon className="h-4 w-4 text-red-500" />
            <span>Categoría: {nextRace.category}</span>
          </div>
        </div>

        <div>
          <p className="text-gray-300">{nextRace.description}</p>
        </div>

        <div className="grid grid-cols-2 gap-4 rounded-lg bg-gray-900 p-4">
          <div>
            <h4 className="font-medium text-yellow-500">Clima</h4>
            <p className="text-sm text-gray-400">{nextRace.weatherForecast}</p>
          </div>
          <div>
            <h4 className="font-medium text-yellow-500">Vueltas</h4>
            <p className="text-sm text-gray-400">
              {nextRace.laps} vueltas ({nextRace.distance})
            </p>
          </div>
        </div>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button
          variant="outline"
          className="border-yellow-500 text-yellow-500 hover:bg-yellow-500 hover:text-black"
          asChild
        >
          <Link href={`/circuitos/${nextRace.circuit.toLowerCase().replace(/\s+/g, "-")}`}>Detalles del Circuito</Link>
        </Button>
        <Button className="bg-red-600 hover:bg-red-700 text-white" asChild>
          <Link href={`/calendario/${nextRace.id}`}>Más Información</Link>
        </Button>
      </CardFooter>
    </Card>
  )
}
