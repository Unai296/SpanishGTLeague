import Link from "next/link"
import { Trophy } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

export function DriverStandings() {
  // En una aplicación real, estos datos vendrían de una API o base de datos
  const standings = [
    {
      position: 1,
      driver: "Carlos Martínez",
      team: "Racing Bulls",
      avatar: "/placeholder.svg?height=40&width=40",
      points: 210,
      wins: 4,
    },
    {
      position: 2,
      driver: "Miguel Sánchez",
      team: "Speed Masters",
      avatar: "/placeholder.svg?height=40&width=40",
      points: 185,
      wins: 3,
    },
    {
      position: 3,
      driver: "Javier López",
      team: "Velocity Racing",
      avatar: "/placeholder.svg?height=40&width=40",
      points: 170,
      wins: 2,
    },
    {
      position: 4,
      driver: "Antonio García",
      team: "Apex Predators",
      avatar: "/placeholder.svg?height=40&width=40",
      points: 156,
      wins: 1,
    },
    {
      position: 5,
      driver: "David Rodríguez",
      team: "Turbo Racers",
      avatar: "/placeholder.svg?height=40&width=40",
      points: 142,
      wins: 1,
    },
    {
      position: 6,
      driver: "Alejandro Fernández",
      team: "Drift Kings",
      avatar: "/placeholder.svg?height=40&width=40",
      points: 128,
      wins: 0,
    },
    {
      position: 7,
      driver: "Sergio Gómez",
      team: "Racing Bulls",
      avatar: "/placeholder.svg?height=40&width=40",
      points: 115,
      wins: 0,
    },
    {
      position: 8,
      driver: "Pablo Martín",
      team: "Speed Masters",
      avatar: "/placeholder.svg?height=40&width=40",
      points: 98,
      wins: 0,
    },
  ]

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-2xl">Clasificación de Pilotos</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="rounded-lg border">
          <div className="grid grid-cols-12 gap-2 border-b bg-muted p-3 text-sm font-medium">
            <div className="col-span-1 text-center">#</div>
            <div className="col-span-5">Piloto</div>
            <div className="col-span-3 hidden sm:block">Equipo</div>
            <div className="col-span-2 text-right">Puntos</div>
            <div className="col-span-1 text-right">
              <Trophy className="ml-auto h-4 w-4" />
              <span className="sr-only">Victorias</span>
            </div>
          </div>
          {standings.map((driver) => (
            <div
              key={driver.position}
              className={`grid grid-cols-12 gap-2 border-b p-3 text-sm last:border-0 ${
                driver.position <= 3 ? "bg-muted/30" : ""
              }`}
            >
              <div className="col-span-1 text-center font-medium">{driver.position}</div>
              <div className="col-span-5 flex items-center gap-2">
                <Avatar className="h-6 w-6">
                  <AvatarImage src={driver.avatar || "/placeholder.svg"} alt={driver.driver} />
                  <AvatarFallback>{driver.driver.charAt(0)}</AvatarFallback>
                </Avatar>
                <span className="truncate">{driver.driver}</span>
              </div>
              <div className="col-span-3 hidden items-center sm:flex">
                <span className="truncate text-muted-foreground">{driver.team}</span>
              </div>
              <div className="col-span-2 text-right font-medium">{driver.points}</div>
              <div className="col-span-1 text-right font-medium">{driver.wins}</div>
            </div>
          ))}
        </div>
      </CardContent>
      <CardFooter>
        <Button className="w-full" asChild>
          <Link href="/clasificaciones">Ver Clasificación Completa</Link>
        </Button>
      </CardFooter>
    </Card>
  )
}
