"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Menu } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-black text-white">
      <div className="container flex h-16 items-center justify-between">
        <Link href="/" className="flex items-center gap-2">
          <Image
            src="/images/spanish-gt-league-logo.webp"
            alt="Spanish GT League Logo"
            width={50}
            height={50}
            className="rounded-md"
          />
          <span className="hidden text-xl font-bold md:inline-block">Spanish GT League</span>
        </Link>

        <nav className="hidden md:flex md:gap-6">
          <Link href="/calendario" className="text-sm font-medium transition-colors hover:text-red-500">
            Calendario
          </Link>
          <Link href="/equipos" className="text-sm font-medium transition-colors hover:text-red-500">
            Equipos
          </Link>
          <Link href="/reglamento" className="text-sm font-medium transition-colors hover:text-red-500">
            Reglamento
          </Link>
        </nav>

        <div className="flex items-center gap-4">
          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild>
              <Button variant="outline" size="icon" className="md:hidden border-white/20 bg-black hover:bg-black/80">
                <Menu className="h-5 w-5 text-white" />
                <span className="sr-only">Abrir menú</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[300px] sm:w-[400px] bg-black text-white">
              <nav className="flex flex-col gap-4">
                <Link href="/" className="flex items-center gap-2 py-2" onClick={() => setIsOpen(false)}>
                  <Image
                    src="/images/spanish-gt-league-logo.webp"
                    alt="Spanish GT League Logo"
                    width={50}
                    height={50}
                    className="rounded-md"
                  />
                  <span className="text-xl font-bold">Spanish GT League</span>
                </Link>
                <Link
                  href="/calendario"
                  className="py-2 text-lg font-medium transition-colors hover:text-red-500"
                  onClick={() => setIsOpen(false)}
                >
                  Calendario
                </Link>
                <Link
                  href="/equipos"
                  className="py-2 text-lg font-medium transition-colors hover:text-red-500"
                  onClick={() => setIsOpen(false)}
                >
                  Equipos
                </Link>
                <Link
                  href="/reglamento"
                  className="py-2 text-lg font-medium transition-colors hover:text-red-500"
                  onClick={() => setIsOpen(false)}
                >
                  Reglamento
                </Link>
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  )
}
